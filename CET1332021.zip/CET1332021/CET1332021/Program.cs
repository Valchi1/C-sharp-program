﻿using System;
using System.Text.RegularExpressions;


namespace CET1332021
{
    class MainClass
    {
        public static void Main(string[] args)
        {

            string sStudentName;//Variable used to store student name
            string sStudentNumber;

            Console.WriteLine("Enter student name");//Displaying "Enter student name"
            sStudentName = Console.ReadLine();//saves the student name entered by the student
            Console.WriteLine();
            Console.WriteLine("Enter student Number");

            sStudentNumber = Console.ReadLine();

            while (!Regex.IsMatch(sStudentNumber, "^\\d{9}$"))//validating if the student number entered is 9 digits
            {
                Console.WriteLine("Error,Enter a 9 digit student number ");//Displaying error message
                sStudentNumber = Console.ReadLine();

            }

            Console.Clear();//It is used to clear the screen and console buffer 


            Console.WriteLine("Enter module marks for each course:");

            int[] iMmarks = new int[6];//array to store 6 module marks
            int imultiplier;
            bool bpositive;

            for (imultiplier = 0; imultiplier < 6; imultiplier++)
            {
                try
                {
                    Console.WriteLine("\nEnter module mark " + (imultiplier + 1));//displaying enter module marks 6 times for 6 different courses.


                    iMmarks[imultiplier] = Convert.ToInt32(Console.ReadLine());//storing the 6 scores entered by the user 
                    bpositive = false;

                    while (bpositive == false)
                    {
                        bpositive = true;
                        if (iMmarks[imultiplier] < 1 || iMmarks[imultiplier] > 100)//validating if the number entered is between 1 and 100
                        {
                            Console.WriteLine("Error, enter a number between 1 and 100");
                            Console.WriteLine("Enter module mark " + (imultiplier + 1));//telling the user to re-enter the score
                            iMmarks[imultiplier] = Convert.ToInt32(Console.ReadLine());

                        }


                    }
                }
                catch//to stop the program from crashing when an invalid value(alphabet) is entered
                {
                    Console.WriteLine("error");
                    Console.WriteLine("Enter module mark " + (imultiplier + 1));
                    iMmarks[imultiplier] = Convert.ToInt32(Console.ReadLine());



                }
            }
            //calculating the average score of the module marks
            int iAverage = 0;
            for (imultiplier = 0; imultiplier < 6; imultiplier++)
            {
                iAverage = iAverage + iMmarks[imultiplier];
            }
            iAverage = iAverage / 6;










            Console.WriteLine("    \nRESULT PAGE   ");//displaying result page
            Console.WriteLine("\nStudent Name:" + sStudentName);//displaying the student name
            Console.WriteLine("\nStudent Number" + sStudentNumber);


            for (imultiplier = 0; imultiplier < 6; imultiplier++)//printing out the module marks entered 
            {
                Console.WriteLine("\nModule score " + (imultiplier + 1) + ": " + iMmarks[imultiplier]);
            }
            Console.WriteLine("\nAverage score: " + iAverage);//Displaying the average score

            //using the average marks to determine if the student passed or failed
            if (iAverage < 40)
            {
                Console.WriteLine("\nYou have failed");
            }
            else
            {
                Console.WriteLine("\nCongrats!!!, You passed");
                Console.WriteLine();

            }

            //tells the user to end the program
            Console.WriteLine();
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();




        }
    }
}

